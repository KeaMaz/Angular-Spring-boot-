package com.example.OwnTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwnTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(OwnTestApplication.class, args);
	}

}
