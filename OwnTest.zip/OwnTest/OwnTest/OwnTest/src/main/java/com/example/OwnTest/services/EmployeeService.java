package com.example.OwnTest.services;

import com.example.OwnTest.models.Employee;
import com.example.OwnTest.models.Role;
import com.example.OwnTest.repositories.EmployeeRepo;
import com.example.OwnTest.repositories.RoleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private RoleRepo roleRepo;

    public List<Employee> getAllEmployee(){
        return (List<Employee>) employeeRepo.findAll();
    }

    public void addEmployee(Employee employee){
        employeeRepo.save(employee);
    }

    public Optional<Employee> getSingleEmployee(Long id){
        return employeeRepo.findById(id);
    }

    public void updateEmployee(Long id, Employee employee){
        employeeRepo.save(employee);
    }

    public void deleteEmployee(Long id){
        employeeRepo.deleteById(id);
    }

    public Employee findByEmployeeName(String name){
        return employeeRepo.findByEmpName(name);
    }

    public List<Role> getAllRole(){
        return (List<Role>) roleRepo.findAll();
    }
}
