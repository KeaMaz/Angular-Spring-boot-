package com.example.OwnTest.repositories;

import com.example.OwnTest.models.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepo  extends CrudRepository<Employee, Long> {
    public Employee findByEmpName(String name);
}
