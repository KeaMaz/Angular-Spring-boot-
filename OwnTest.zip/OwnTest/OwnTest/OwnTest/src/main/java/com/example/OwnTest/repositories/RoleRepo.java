package com.example.OwnTest.repositories;

import com.example.OwnTest.models.Role;
import org.springframework.data.repository.CrudRepository;



public interface RoleRepo extends CrudRepository<Role, Long> {
}
